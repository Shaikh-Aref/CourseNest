﻿namespace CourseNest.Constants;

public enum PaymentMethods
{
    NetBanking=1,
    Online
}
