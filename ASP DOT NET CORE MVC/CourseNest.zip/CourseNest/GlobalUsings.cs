﻿global using CourseNest.Data;
global using CourseNest.Models;
global using CourseNest.Models.DTOs;
global using CourseNest.Repositories;
global using CourseNest.Constants;