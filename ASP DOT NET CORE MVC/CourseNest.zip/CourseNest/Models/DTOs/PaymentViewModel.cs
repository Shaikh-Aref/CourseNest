﻿namespace CourseNest.Models.DTOs
{
    public class PaymentViewModel
{
    public string Key { get; set; }
    public string OrderId { get; set; }
    public int Amount { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string Contact { get; set; }
}
}