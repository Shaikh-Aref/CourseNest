﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using CourseNest.AppDbContext;
using CourseNest.Models.DTO;

namespace CourseNest.Controllers
{
    [ApiController]
    [Route("CourseNest/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly string? _key;
        private readonly string? _issuer;
        private readonly string? _audience;

        public AuthController(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _key = configuration["Jwt:Key"];
            _issuer = configuration["Jwt:Issuer"];
            _audience = configuration["Jwt:Audience"];
        }

        [HttpPost("instructor/login")]
        public async Task<IActionResult> LoginInstructor(LoginDTO loginDto)
        {
            var instructor = await _context.Instructors
                .SingleOrDefaultAsync(i => i.Email == loginDto.Email);

            if (instructor == null || !BCrypt.Net.BCrypt.Verify(loginDto.Password, instructor.Password))
            {
                return Unauthorized("Invalid email or password.");
            }

            var token = GenerateJwtToken(instructor.Email);
            return Ok(new { Token = token });
        }

        [HttpPost("student/login")]
        public async Task<IActionResult> LoginStudent(LoginDTO loginDto)
        {
            var student = await _context.Students
                .SingleOrDefaultAsync(s => s.Email == loginDto.Email);

            if (student == null || !BCrypt.Net.BCrypt.Verify(loginDto.Password, student.Password))
            {
                return Unauthorized("Invalid email or password.");
            }

            var token = GenerateJwtToken(student.Email);
            return Ok(new { Token = token });
        }

        private string GenerateJwtToken(string email)
        {
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_key));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                _issuer,
                _audience,
                claims,
                expires: DateTime.UtcNow.AddMinutes(10),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
