﻿using CourseNest.AppDbContext;
using CourseNest.Models.DTO;
using CourseNest.Models.DTOs;
using CourseNest.Models.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CourseNest.Controllers
{
    [Route("CourseNest/[controller]")]
    [ApiController]
    public class InstructorsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public InstructorsController (ApplicationDbContext context)
        {
            _context = context;
        }

        // POST: CourseNest/Instructors
        [HttpPost]
        [AllowAnonymous]
        public async Task<ActionResult> CreateInstructor(InstructorDTO instructorDTO)
        {
            if (instructorDTO is null)
            {
                return BadRequest("Instructor Data is Null");
            }

            var instructor = new Instructor
            {
                FirstName = instructorDTO.FirstName,
                LastName = instructorDTO.LastName,
                Email = instructorDTO.Email,
                PhoneNumber = instructorDTO.PhoneNumber,
                Gender = instructorDTO.Gender,
                Password = BCrypt.Net.BCrypt.HashPassword(instructorDTO.Password)
            };

            _context.Instructors.Add(instructor);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(CreateInstructor), new {id = instructor.Id},instructor);
        }

        // GET: CourseNest/Instructors
        [HttpGet]
        [Authorize]
        public async Task<ActionResult<IEnumerable<InstructorDTO>>> GetInstructors()
        {
            var instructors = await _context.Instructors
                .Select(i => new InstructorDTO
                {
                    Id = i.Id,
                    FirstName = i.FirstName,
                    LastName = i.LastName,
                    Email = i.Email,
                    PhoneNumber = i.PhoneNumber,
                    Gender = i.Gender
                })
                .ToListAsync();

            return Ok(instructors);
        }

        // GET: CourseNest/Instructors/{id}
        [HttpGet("{id}")]
        [Authorize]
        public async Task<ActionResult<InstructorDTO>> GetInstructor(int id)
        {
            var instructor = await _context.Instructors
                .Where(i => i.Id == id)
                .Select(i => new InstructorDTO
                {
                    Id = i.Id,
                    FirstName = i.FirstName,
                    LastName = i.LastName,
                    Email = i.Email,
                    PhoneNumber = i.PhoneNumber,
                    Gender = i.Gender
                })
                .FirstOrDefaultAsync();

            if (instructor == null)
            {
                return NotFound();
            }

            return Ok(instructor);
        }

        // PUT: CourseNest/Instructors/{id}
        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> UpdateInstructor(int id, InstructorDTO instructorDto)
        {
            if (id != instructorDto.Id)
            {
                return BadRequest("Instructor ID mismatch.");
            }

            var instructor = await _context.Instructors.FindAsync(id);

            if (instructor == null)
            {
                return NotFound();
            }

            instructor.FirstName = instructorDto.FirstName;
            instructor.LastName = instructorDto.LastName;
            instructor.Email = instructorDto.Email;
            instructor.PhoneNumber = instructorDto.PhoneNumber;
            instructor.Gender = instructorDto.Gender;
            // Don't update password, consider handling it separately if needed

            try
            {
                _context.Entry(instructor).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!InstructorExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: CourseNest/Instructors/{id}
        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteInstructor(int id)
        {
            var instructor = await _context.Instructors.FindAsync(id);

            if (instructor == null)
            {
                return NotFound();
            }

            _context.Instructors.Remove(instructor);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // POST: CourseNest/Instructors/change_password/{id}
        [HttpPost("change_password/{id}")]
        [Authorize]
        public async Task<IActionResult> ChangePassword(int id, ChangePasswordDTO changePasswordDto)
        {
            var instructor = await _context.Instructors.FindAsync(id);
            if (instructor == null)
            {
                return NotFound();
            }

            if (!BCrypt.Net.BCrypt.Verify(changePasswordDto.OldPassword, instructor.Password))
            {
                return Unauthorized("Old password is incorrect.");
            }

            instructor.Password = BCrypt.Net.BCrypt.HashPassword(changePasswordDto.NewPassword);
            _context.Entry(instructor).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool InstructorExists(int id)
        {
            return _context.Instructors.Any(e => e.Id == id);
        }        

    }
}