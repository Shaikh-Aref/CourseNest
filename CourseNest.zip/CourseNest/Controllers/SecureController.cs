﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CourseNest.Controllers
{
    [ApiController]
    [Route("CourseNest/[controller]")]
    [Authorize]
    public class SecureController : ControllerBase
    {
        [HttpGet("secure-data")]
        public IActionResult GetSecureData()
        {
            return Ok("This is a secure data endpoint.");
        }
    }
}
