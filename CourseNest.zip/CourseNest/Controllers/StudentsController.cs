﻿using CourseNest.AppDbContext;
using CourseNest.Models.DTO;
using CourseNest.Models.DTOs;
using CourseNest.Models.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CourseNest.Controllers
{
    [Route("CourseNest/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        // Constructor
        public StudentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // POST: CourseNest/Students
        [HttpPost]
        [AllowAnonymous]
        public async Task<ActionResult> CreateStudent(StudentDTO studentDto)
        {
            if (studentDto == null)
            {
                return BadRequest("Student data is null.");
            }

            var student = new Student
            {
                FirstName = studentDto.FirstName,
                LastName = studentDto.LastName,
                Email = studentDto.Email,
                PhoneNumber = studentDto.PhoneNumber,
                Gender = studentDto.Gender,
                Password = BCrypt.Net.BCrypt.HashPassword(studentDto.Password) // Hash the password
            };

            _context.Students.Add(student);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(CreateStudent), new { id = student.Id }, student);
        }

        // GET: CourseNest/Students
        [HttpGet]
        [Authorize]
        public async Task<ActionResult<IEnumerable<StudentDTO>>> GetStudents()
        {
            var students = await _context.Students
                .Select(s => new StudentDTO
                {
                    Id = s.Id,
                    FirstName = s.FirstName,
                    LastName = s.LastName,
                    Email = s.Email,
                    PhoneNumber = s.PhoneNumber,
                    Gender = s.Gender
                })
                .ToListAsync();

            return Ok(students);
        }

        // GET: CourseNest/Students/{id}
        [HttpGet("{id}")]
        [Authorize]
        public async Task<ActionResult<StudentDTO>> GetStudent(int id)
        {
            var student = await _context.Students
                .Where(s => s.Id == id)
                .Select(s => new StudentDTO
                {
                    Id = s.Id,
                    FirstName = s.FirstName,
                    LastName = s.LastName,
                    Email = s.Email,
                    PhoneNumber = s.PhoneNumber,
                    Gender = s.Gender
                })
                .FirstOrDefaultAsync();

            if (student == null)
            {
                return NotFound();
            }

            return Ok(student);
        }

        // PUT: CourseNest/Students/{id}
        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> UpdateStudent(int id, StudentDTO studentDto)
        {
            if (id != studentDto.Id)
            {
                return BadRequest("Student ID mismatch.");
            }

            var student = await _context.Students.FindAsync(id);

            if (student == null)
            {
                return NotFound();
            }

            student.FirstName = studentDto.FirstName;
            student.LastName = studentDto.LastName;
            student.Email = studentDto.Email;
            student.PhoneNumber = studentDto.PhoneNumber;
            student.Gender = studentDto.Gender;
            // Don't update password, consider handling it separately if needed

            try
            {
                _context.Entry(student).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StudentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: CourseNest/Students/{id}
        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteStudent(int id)
        {
            var student = await _context.Students.FindAsync(id);

            if (student == null)
            {
                return NotFound();
            }

            _context.Students.Remove(student);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // POST: CourseNest/Instructors/change_password/{id}
        [HttpPost("change_password/{id}")]
        [Authorize]
        public async Task<IActionResult> ChangePassword(int id, ChangePasswordDTO changePasswordDto)
        {
            var student = await _context.Students.FindAsync(id);
            if (student == null)
            {
                return NotFound();
            }

            if (!BCrypt.Net.BCrypt.Verify(changePasswordDto.OldPassword, student.Password))
            {
                return Unauthorized("Old password is incorrect.");
            }

            student.Password = BCrypt.Net.BCrypt.HashPassword(changePasswordDto.NewPassword);
            _context.Entry(student).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool StudentExists(int id)
        {
            return _context.Students.Any(e => e.Id == id);
        }

    }
}
